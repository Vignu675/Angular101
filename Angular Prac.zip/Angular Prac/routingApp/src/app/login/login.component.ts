import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '../../../node_modules/@angular/router';
import { Subscriber } from '../../../node_modules/rxjs';
import { PARAMETERS } from '../../../node_modules/@angular/core/src/util/decorators';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  uname: string;

  constructor(private route: ActivatedRoute) {
    route.params.subscribe(params => this.uname = params['uname']);
   }

  ngOnInit() {
  }

}
