

export interface Employee {
  eid: number;
  ename: string;
  salary: number;
}
