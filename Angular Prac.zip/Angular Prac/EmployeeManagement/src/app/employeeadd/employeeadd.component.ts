import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employeeadd',
  templateUrl: './employeeadd.component.html',
  styleUrls: ['./employeeadd.component.css']
})
export class EmployeeaddComponent implements OnInit {

  constructor(private _service: EmployeeService) { }

  empList: Employee[];

  ngOnInit() {
  }

  addEmployee(addform) {
    this.empList.push(addform.value);
 }



}
