import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import {RouterModule, Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeService } from './employee.service';
import { EmployeeaddComponent } from './employeeadd/employeeadd.component';
const routes: Routes = [

  {path: '', redirectTo: '', pathMatch: 'full'},
  {path: 'home', component: EmployeeComponent},
  {path: 'add', component: EmployeeaddComponent},
];
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    EmployeeaddComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
