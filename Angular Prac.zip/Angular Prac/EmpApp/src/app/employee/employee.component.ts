import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private _service: EmployeeService) { }

  empList: Employee[];
  ngOnInit() {

    this.getAllEmployee();
  }

  getAllEmployee() {
    this._service.getAllEmployees().subscribe(data => this.empList = data);
  }

  deleteEmployee(i) {

    this.empList.splice(i, 1);
  }

  delete(myform) {
    for (let i = 0; i < this.empList.length; i++) {
        if (this.empList[i].eid == myform.value.eid) {
            this.empList.splice(i, 1);
    }
        else {
            alert("No such Employee Id as" + myform.value.eid);
           }
     }
  }

    addEmployee(addform) {
       this.empList.push(addform.value);
    }

    updateEmployee(updateform) {
      for (let i = 0; i < this.empList.length; i++) {
        if (this.empList[i].eid == updateform.value.eid) {
        this.empList[i] = updateform.value;
        }

        else {
          alert("Can't be Updated");
        }
    }


  }

}
