import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';

@Component({
 selector: 'app-listallemployees',
 templateUrl: './listallemployees.component.html',
 styleUrls: ['./listallemployees.component.css']
})
export class ListallEmployeesComponent implements OnInit {
  empId: number;
  empName: string;
  empEmail: string;
  empPhone: number;
 employeeServiceObj: EmployeeService = new EmployeeService();
 empList: Employee[] = [];

 constructor() { }

 ngOnInit() {
 this.empList = this.employeeServiceObj.listEmployeeService();
 }

 deleteEmployee(i) {
 this.employeeServiceObj.deleteEmployeeService(i);
 }


 updateEmployee(i) {
 this.empId = this.empList[i].id;
 this.empName = this.empList[i].name;
 this.empEmail = this.empList[i].email;
 this.empPhone = this.empList[i].phone;
 }

 empUpdate(val) {
 this.empList = this.employeeServiceObj.empUpdateService(val);
 }

}
