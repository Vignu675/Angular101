import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../product';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private ser:ProductService) { }

  searchList:Product[];
  showList:Product[]=[];

  ngOnInit() {
    this.list();
  }

  list() {
    this.ser.getData().subscribe(x=>this.searchList=x);
  }

  // find(data) {
  //   let j=0;
  //   for(let i=0;i<this.searchList.length;i++) {
  //     if(data.nm==this.searchList[i].name) {
  //       alert(data.nm)
  //       this.showList[j]=this.searchList[i];
  //     }
  //   }
  // }

  find(data) {
    this.showList=this.ser.search(data,this.searchList);
  }

}
