import { Injectable } from '@angular/core';
import { Product } from './product';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Observable } from '../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  shlist: Product[] = [];

  jdata = '/assets/prod.json';

  getData(): Observable<Product[]> {
    return this.http.get<Product[]>(this.jdata);
  }


  deleteProd(i, list) {
    list.splice(i, 1);
    return list;
  }

  search(data, list) {
    const j = 0;
    for (let i = 0; i < list.length; i++) {
      if (data.nm === list[i].name) {
        alert(data.nm);
        this.shlist[j] = list[i];
      }
    }
    return this.shlist;

  }

}
