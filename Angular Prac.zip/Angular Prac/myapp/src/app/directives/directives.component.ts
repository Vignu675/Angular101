import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  isValid = false;
  name: string="Welcome!";
  jsonobj = {eid: '101', ename: 'Sri', salary: 43000};
  choice = 1;
  cities = ["Kakinada","Vizag","Hyderabad","chennai"];

  constructor() { }

  ngOnInit() {
  }

}
