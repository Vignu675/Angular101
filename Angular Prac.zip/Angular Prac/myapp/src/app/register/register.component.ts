import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  submitted = false;

  uname: string;
  pwd: string;


  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {

  this.registerForm = this.formBuilder.group({
    uname: ['', [Validators.required, Validators.minLength(4)]],
    pwd: ['', [Validators.required, Validators.pattern('[A-Z]{5}')]]
  });
  }

  get f() {
    return this.registerForm.controls;
  }

  onSubmit(data) {
    this.submitted = true;

    if (this.registerForm.invalid) {
      return;
    }
    alert("Form Submitted Successfully"+data.uname);
    this.uname = data.uname;
    this.pwd = data.pwd;
  }

}
