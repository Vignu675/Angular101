import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor() { }



  student = {"sid":"4A8","sname":"Vignesh","course":"Java"};

getStudent() {
  console.log('Student Getter');
}
}
