import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appChangeText]'
})
export class ChangeTextDirective {

  constructor(private ele: ElementRef) {

    ele.nativeElement.innerText = "Hello Text is Changed";
  }

  @HostListener('mouseover') onHover() {
        alert('Hello');
  }
}
