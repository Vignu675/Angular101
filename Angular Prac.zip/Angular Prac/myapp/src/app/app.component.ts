import { Component } from '@angular/core';

@Component({
  selector: 's1',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Capgemini';

  parentValue: string ="I'am Parent"


  id:number = 190122;
  name:string = 'Manikya';
  isValid:boolean = true;
  value:any = 'anyvalue';

  image: string = "assets/v.jpg";

  city: string = "Chennai";

  sayHello() {
    alert("Astala Vista...");
}

  getData(value) {
    alert(value);
  }
}
